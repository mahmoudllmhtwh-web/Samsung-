package com.example.phonegallery3d

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhoneGalleryApp() }
    }
}

private data class Phone(
    val name: String, val subtitle: String, val color: Color,
    val screen: String, val processor: String, val camera: String,
    val battery: String, val display: String, val storage: String,
    val highlights: List<String>
)

private val phones = listOf(
    Phone(
        "Samsung Galaxy S26 Ultra", "القوة القصوى والتصوير الاحترافي",
        Color(0xFF8D9AA7), "6.9 بوصة • AMOLED",
        "معالج رائد من فئة Snapdragon / Exynos حسب السوق",
        "كاميرا رئيسية عالية الدقة مع تقريب بصري متعدد",
        "بطارية كبيرة مع شحن سريع ولاسلكي",
        "Dynamic AMOLED • معدل تحديث تكيفي",
        "256GB / 512GB / 1TB",
        listOf("قلم S Pen مدمج", "تصوير وتقريب متقدم", "شاشة كبيرة وساطعة")
    ),
    Phone(
        "iPhone 17 Pro Max", "أداء قوي وتجربة iOS متكاملة",
        Color(0xFFB6A08C), "6.9 بوصة تقريباً • OLED",
        "Apple A19 Pro",
        "نظام كاميرات Pro مع تقريب بصري",
        "بطارية محسّنة للاستخدام الطويل",
        "Super Retina XDR OLED • ProMotion",
        "256GB / 512GB / 1TB / 2TB",
        listOf("تصوير فيديو احترافي", "زر الإجراءات والتحكم بالكاميرا", "نظام iOS")
    ),
    Phone(
        "Samsung Galaxy S26", "حجم عملي وأداء رائد",
        Color(0xFF9DB6A7), "6.3 بوصة تقريباً • AMOLED",
        "معالج رائد من فئة Snapdragon / Exynos حسب السوق",
        "كاميرات متعددة للاستخدام اليومي",
        "بطارية متوازنة مع شحن سريع",
        "Dynamic AMOLED • معدل تحديث تكيفي",
        "128GB / 256GB / 512GB",
        listOf("تصميم مدمج وخفيف", "شاشة سلسة", "ميزات Galaxy الذكية")
    )
)

@Composable
private fun PhoneGalleryApp() {
    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF0A1018), surface = Color(0xFF141E2A),
        primary = Color(0xFF75E0C0), onSurface = Color(0xFFF3F6FA)
    )) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(Color(0xFF0A1018)),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 28.dp, bottom = 36.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Text("PHONE LAB", color = Color(0xFF75E0C0), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("معرض الهواتف", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("اكتشف التفاصيل وجرّب تدوير كل هاتف بمنظور ثلاثي الأبعاد", color = Color(0xFF9EADBC), fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tag("3 هواتف")
                        Tag("عرض تفاعلي 3D")
                        Tag("مقارنة المواصفات")
                    }
                }
                items(phones) { phone -> PhoneCard(phone) }
                item {
                    Text("ملاحظة: بعض المواصفات قد تختلف حسب البلد والنسخة. راجع موقع الشركة قبل الشراء.",
                        color = Color(0xFF8292A3), fontSize = 11.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun Tag(text: String) {
    Box(Modifier.clip(CircleShape).background(Color(0xFF1B2B36)).padding(horizontal = 11.dp, vertical = 7.dp)) {
        Text(text, color = Color(0xFF9DEBD6), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PhoneCard(phone: Phone) {
    var rotation by remember { mutableFloatStateOf(-12f) }
    var flipped by remember { mutableStateOf(false) }
    val animatedRotation by animateFloatAsState(rotation, label = "phoneRotation")
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141E2A)),
        shape = RoundedCornerShape(25.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(phone.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(phone.subtitle, color = Color(0xFF9EADBC), fontSize = 12.sp)
                }
                Box(Modifier.size(10.dp).clip(CircleShape).background(phone.color))
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxWidth().height(200.dp).background(
                    Brush.radialGradient(listOf(phone.color.copy(alpha = .20f), Color.Transparent))
                ))
                PhoneRender(
                    color = phone.color, back = flipped, rotationY = animatedRotation,
                    modifier = Modifier.width(132.dp).height(238.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                rotation = (rotation + drag.x * .75f).coerceIn(-65f, 65f)
                            }
                        }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { flipped = !flipped }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF9DEBD6))) {
                    Text(if (flipped) "اعرض الواجهة" else "اقلب الهاتف")
                }
                OutlinedButton(onClick = { rotation = 0f }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                    Text("إعادة الضبط")
                }
            }
            Spacer(Modifier.height(15.dp))
            Text("المواصفات الرئيسية", color = Color(0xFF75E0C0), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            SpecRow("الشاشة", phone.display)
            SpecRow("المعالج", phone.processor)
            SpecRow("الكاميرا", phone.camera)
            SpecRow("البطارية", phone.battery)
            SpecRow("التخزين", phone.storage)
            Spacer(Modifier.height(10.dp))
            phone.highlights.forEach { item ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF75E0C0)))
                    Spacer(Modifier.width(8.dp))
                    Text(item, color = Color(0xFFD3DCE5), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(7.dp))
            Text("اسحب الهاتف يميناً أو يساراً لتغيير زاوية العرض.",
                color = Color(0xFF8292A3), fontSize = 10.sp)
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = Color(0xFF93A4B5), fontSize = 11.sp, modifier = Modifier.width(66.dp))
        Text(value, color = Color(0xFFE8EEF4), fontSize = 11.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun PhoneRender(color: Color, back: Boolean, rotationY: Float, modifier: Modifier = Modifier) {
    Box(
        modifier.graphicsLayer {
            this.rotationY = rotationY + if (back) 180f else 0f
            rotationX = -5f
            cameraDistance = 18f * density
            shadowElevation = 22f
            shape = RoundedCornerShape(27.dp)
            clip = true
        }.background(
            Brush.linearGradient(listOf(color.copy(alpha = .95f), Color(0xFF202B38), color.copy(alpha = .8f)))
        ).padding(5.dp)
    ) {
        Canvas(Modifier.fillMaxSize().clip(RoundedCornerShape(23.dp))) {
            val w = size.width
            val h = size.height
            drawRoundRect(Color(0xFF080D14), cornerRadius = androidx.compose.ui.geometry.CornerRadius(23.dp.toPx()))
            if (!back) {
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(Color(0xFF142D45), Color(0xFF5A9A91), Color(0xFF17243B))),
                    topLeft = androidx.compose.ui.geometry.Offset(4.dp.toPx(), 4.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(w - 8.dp.toPx(), h - 8.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx())
                )
                drawCircle(Color(0xFF090D13), radius = 5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(w/2, 13.dp.toPx()))
                drawCircle(Color(0xFFB8E7DC).copy(alpha = .23f), radius = w*.32f, center = androidx.compose.ui.geometry.Offset(w*.72f, h*.65f))
                drawLine(Color.White.copy(alpha = .12f), androidx.compose.ui.geometry.Offset(w*.12f,h*.28f), androidx.compose.ui.geometry.Offset(w*.88f,h*.28f), 2.dp.toPx())
            } else {
                drawRoundRect(color.copy(alpha = .95f), topLeft = androidx.compose.ui.geometry.Offset(4.dp.toPx(),4.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(w-8.dp.toPx(),h-8.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx()))
                val centers = listOf(
                    androidx.compose.ui.geometry.Offset(w*.24f,h*.15f),
                    androidx.compose.ui.geometry.Offset(w*.24f,h*.29f),
                    androidx.compose.ui.geometry.Offset(w*.24f,h*.43f)
                )
                centers.forEach {
                    drawCircle(Color(0xFF111923), 13.dp.toPx(), it)
                    drawCircle(Color(0xFF627D91), 8.dp.toPx(), it, style = Stroke(2.dp.toPx()))
                    drawCircle(Color(0xFFB7D9E8).copy(alpha=.55f), 2.dp.toPx(),
                        androidx.compose.ui.geometry.Offset(it.x-3.dp.toPx(),it.y-3.dp.toPx()))
                }
                drawCircle(Color(0xFFE8E8D5), 4.dp.toPx(), androidx.compose.ui.geometry.Offset(w*.73f,h*.15f))
                drawRoundRect(Color.White.copy(alpha=.10f), topLeft=androidx.compose.ui.geometry.Offset(w*.40f,h*.72f),
                    size=androidx.compose.ui.geometry.Size(w*.42f,3.dp.toPx()), cornerRadius=androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
            }
            drawRoundRect(Color.White.copy(alpha=.16f), style=Stroke(1.dp.toPx()),
                cornerRadius=androidx.compose.ui.geometry.CornerRadius(23.dp.toPx()))
        }
    }
}
